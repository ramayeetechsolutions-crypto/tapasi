<br><br><br>
<?php
session_start();
// NOTE: Assuming db.php and header.php exist and set up connections/HTML header
require 'db.php'; 

//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

$uid = $_SESSION['uid'] ?? 0;
$showEditButton = false;
$process_ids = [];

if($uid){
    // Fetch user role and processes
    $stmt = $mysqli->prepare("SELECT process, user_role_id FROM employee_master WHERE employee_id=?");
    
    if ($stmt) {
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $stmt->bind_result($process, $user_role_id);
        
        if($stmt->fetch()){
            // Get user's process IDs
            $process_ids = array_filter(array_map('trim', explode(',', $process)));

            // Authorize user if they have any of the core CE processes (7, 8, 9, 10, 11)
            $allowed_processes = ['7', '8', '9', '10', '11'];
            
            // Check if the user's process list intersects with the allowed list
            if (count(array_intersect($process_ids, $allowed_processes)) > 0) {
                $showEditButton = true;
            }
        }
        $stmt->close();
    }
}

$showEditButtonJson = json_encode($showEditButton);
// Pass the full process list to JavaScript for granular control
$processIdsJson = json_encode($process_ids); 
?>
<?php require 'header.php';?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<meta charset="UTF-8">
<title>CE Table Inline Edit</title>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<style>
/* CSS for Spinner Animation */
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
.spin {
    animation: spin 1s linear infinite;
}

td.editable { cursor: pointer; } 

/* Status-based row colors */
.status-need { background-color: #dc3545 !important; color: #fff !important; }    
.status-progress { background-color: #ffc107 !important; color: #000 !important; } 
.status-completed { background-color: #28a745 !important; color: #fff !important; } 

/* Cell coloring override based on flag value */
.red-bg { background-color: #f8d7da !important; color: #721c24; }      
.yellow-bg { background-color: #fffae0 !important; color: #664d03; }  
.green-bg { background-color: #d4edda !important; color: #155724; }  

/* Style for cells containing the new assignment button */
td.cell-container { padding-right: 5px !important; }
.cell-content-wrapper { position:relative; width:100%; height:100%; padding-right:35px; }
</style>
    <h3>CE Records</h3>
    <table id="ceTable" class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Job ID</th>
                <th>Date</th>
                <th>Client</th>
                <th>Issue</th>
                <th>Articles</th>
                <th>EQ</th>
                <th>Images</th>
                <th>Tables</th>
                <th>Process</th>
                <th>Word Count</th>
                <th>Ref</th>
                <th>TAT</th>
                <th>Status</th>
                <th>CE By</th>
                <th>CE Date</th>
                <th></th> </tr>
        </thead>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function(){
    var showEditButton = <?php echo $showEditButtonJson; ?>;
    var userProcessIds = <?php echo $processIdsJson; ?>;

    var table = $('#ceTable').DataTable({
        ajax: 'ce_fetch.php',
        columns: [
            {data: 'id'},
            {data: 'job_id'},
            {data: 'date'},
            {data: 'client'},
            {data: 'issue'},
            {data: 'articles'},
            {data: 'eq'},
            {data: 'images'},
            {data: 'tables_count'},
            {data: 'process'},
            {data: 'word_count'},
            {data: 'ref'},
            {data: 'tat'},
            {data: 'status'},
            {data: 'done_by'},
            {data: 'ce_date'},
            {data: null} // Action Column (Index 16)
        ],
        columnDefs: [
            {
                targets: 16, // Action Column
                data: null,
                render: function(data, type, row) {
                    return ''; 
                },
                orderable: false,
                searchable: false
            }
        ],
        rowCallback: function(row, data){
            var isCompleted = (data.status === 'Completed');
            
            // 1. Row Status Coloring
            $(row).removeClass('status-need status-progress status-completed text-dark text-white');
            
            switch(data.status){
                case 'Need to Assign': 
                    $(row).addClass('status-need'); 
                    break;
                case 'In Progress': 
                    $(row).addClass('status-progress'); 
                    break;
                case 'Completed': 
                    $(row).addClass('status-completed'); 
                    break;
            }

            // 2. Cell Coloring and Editable Logic based on _check flags (0, 1, 2)
            // Map the column index to the required process ID
            var quantityAndRefCols = [
                // Col Index : DB Field : Check Field : Required Process ID
                { index: 6, field: 'eq', check_field: 'eq_check', required_process: '8' },         // EQ (Equation)
                { index: 7, field: 'images', check_field: 'images_check', required_process: '10' }, // Images
                { index: 8, field: 'tables_count', check_field: 'tables_count_check', required_process: '9' }, // Tables
                { index: 11, field: 'ref', check_field: 'ref_check', required_process: '11' }      // Ref
            ];
            
            quantityAndRefCols.forEach(function(col) {
                var cell = $('td', row).eq(col.index);
                var check_value = parseInt(data[col.check_field]) || 0; 
                
                // --- Reset cell content and classes ---
                var originalData = data[col.field];
                cell.empty().text(originalData); 
                cell.removeClass('editable red-bg green-bg yellow-bg cell-container');
                cell.css('padding-right', ''); 
                // --------------------------------------
                
                // Check if the user is authorized for this specific column's process
                var isAuthorizedForProcess = userProcessIds.includes(col.required_process);

                if (!isCompleted && showEditButton) {
                    
                    if (check_value === 0) {
                        // FLAG 0: RED CELL 
                        cell.addClass('red-bg'); 
                        cell.attr('data-id', data.id);

                        if (isAuthorizedForProcess) {
                             // Only show button if authorized for this specific process
                             cell.addClass('editable cell-container');
                             cell.css('padding-right', '5px'); 
                             
                             var btnHtml = '<button class="btn btn-sm btn-primary assign-cell-btn" data-id="'+data.id+'" data-field="'+col.field+'" title="Assign this item to me" style="position:absolute; top:2px; right:2px; padding: 2px 5px;"><i class="bi bi-person-fill-add"></i></button>';
                             
                             // Wrap cell content to make space for the button
                             cell.empty().append('<div class="cell-content-wrapper" style="position:relative; width:100%; height:100%; padding-right:35px;">' + originalData + btnHtml + '</div>');
                        }


                    } else if (check_value === 1) { 
                        // FLAG 1: YELLOW CELL (Assigned, Editable, NO BUTTON)
                        cell.empty().text(originalData);
                        cell.addClass('yellow-bg');
                        // Cell is only editable if the user has the required process
                        if (isAuthorizedForProcess) {
                            cell.addClass('editable'); 
                        }
                        cell.attr('data-id', data.id);
                        
                    } else if (check_value === 2) { 
                        // FLAG 2: GREEN CELL (Completed, Not editable)
                           cell.addClass('green-bg'); 
                    }
                } else if (check_value === 2 || isCompleted) {
                    cell.addClass('green-bg'); 
                }
            });
            
            // 3. Word Count (10) and Status (13) columns
            
            // Word Count (Column 10) - Requires Process 7
            var isWordCountAuthorized = userProcessIds.includes('7');
            if (!isCompleted && showEditButton && isWordCountAuthorized) {
                $('td', row).eq(10).addClass('editable').attr('data-id', data.id); 
            }
            
            // Status (Column 13) - Editable if general edit is enabled and not completed
            if (!isCompleted && showEditButton) {
                $('td', row).eq(13).addClass('editable').attr('data-id', data.id); 
            }
        }
    });

// --------------------------------------------------------------------------------
// 1. YELLOW CELL HANDLER (Flag 1 -> Flag 2: The SECOND Click / Final Entry)
// --------------------------------------------------------------------------------
$('#ceTable').on('click', 'td.yellow-bg.editable', function(){
    if($(this).find('input, select').length > 0) return;

    var cell = table.cell(this);
    var oldValue = cell.data();
    var id = $(this).data('id');
    var colIndex = cell.index().column;

    var fieldMap = {6:'eq', 7:'images', 8:'tables_count', 11:'ref'};
    var field = fieldMap[colIndex];
    if (!field) return; 
    
    // Extract only the number if the old value is the 'Username / In Progress' string
    var numberMatch = String(oldValue).match(/(\d+)/);
    var initialValue = numberMatch ? numberMatch[0] : '';

    $(this).html('<input type="text" class="form-control form-control-sm" value="'+initialValue+'">');
    $(this).find('input').focus().select();

    $(this).find('input').on('blur keyup', function(e){
        if(e.type === 'blur' || e.key === 'Enter'){
            var newValue = $(this).val();
            
            if(String(newValue).trim() === String(initialValue).trim()){
                table.row(cell.index().row).invalidate().draw(); 
                return;
            }

            var postData = {
                id: id, 
                [field]: newValue, 
                update_ce_date: 1,  
                set_check_flag: 2   
            };
            
            $.post('ce_update.php', postData, function(res){
                if(res.success){
                    cell.data(res.new_data).draw(); 
                    table.row(cell.index().row).invalidate().draw(); // Redraw for Green color
                } else {
                    alert(res.error || 'Update failed on second click');
                    table.row(cell.index().row).invalidate().draw();
                }
            }, 'json').fail(function() {
                 alert('Server communication failed for second click update.');
                 table.row(cell.index().row).invalidate().draw();
            });
        }
    });
});


// --------------------------------------------------------------------------------
// 2. RED CELL HANDLER (Flag 0 -> Flag 2: The FIRST Click - Manual Edit)
// --------------------------------------------------------------------------------
$('#ceTable').on('click', 'td.red-bg.editable', function(){
    // Prevent if the user is authorized for the button (manual edit should only be possible if the button isn't there)
    if($(this).find('.assign-cell-btn').length > 0) return; 
    
    if($(this).find('input, select').length > 0) return;

    var cell = table.cell(this);
    var oldValue = cell.data();
    var id = $(this).data('id');
    var colIndex = cell.index().column;

    var fieldMap = {6: 'eq', 7: 'images', 8: 'tables_count', 11: 'ref'};
    var field = fieldMap[colIndex];
    if (!field) return; 
    
    $(this).html('<input type="text" class="form-control form-control-sm" value="'+oldValue+'">');
    $(this).find('input').focus().select();

    $(this).find('input').on('blur keyup', function(e){
        if(e.type === 'blur' || e.key === 'Enter'){
            var newValue = $(this).val();
            
            if(String(newValue).trim() === String(oldValue).trim()){
                table.row(cell.index().row).invalidate().draw();
                return;
            }

            newValue = String(newValue).trim(); 
            var flag_to_set = 2; 

            var postData = {
                id: id, 
                [field]: newValue, 
                set_check_flag: flag_to_set,
                update_ce_date: 1 
            };
            
            $.post('ce_update.php', postData, function(res){
                if(res.success){
                    cell.data(newValue).draw();
                    table.row(cell.index().row).invalidate().draw(); 
                } else { 
                    alert(res.error || 'Update failed'); 
                    table.row(cell.index().row).invalidate().draw();
                }
            }, 'json').fail(function() {
                 alert('Server communication failed for first click update.');
                 table.row(cell.index().row).invalidate().draw();
            });
        }
    });
});

// --------------------------------------------------------------------------------
// 3. GENERIC SINGLE CLICK HANDLER (Word Count / Status)
// --------------------------------------------------------------------------------
$('#ceTable').on('click', 'td.editable:not(.red-bg):not(.yellow-bg)', function(){
    // Prevent multiple editors in one cell
    if($(this).find('input, select').length > 0) return;

    var cell = table.cell(this);
    var oldValue = cell.data();
    var id = $(this).data('id');
    var colIndex = cell.index().column;

    var fieldMap = {10: 'word_count', 13: 'status'};
    var field = fieldMap[colIndex];
    if (!field) return; 

    // For Status column (13), use a dropdown
    if (field === 'status') {
        var statusOptions = ['In Progress', 'Completed'];
        var selectHtml = '<select class="form-select form-select-sm">';
        statusOptions.forEach(function(option) {
            var selected = (option === oldValue) ? 'selected' : '';
            selectHtml += '<option value="'+option+'" '+selected+'>'+option+'</option>';
        });
        selectHtml += '</select>';
        
        cell.data(selectHtml); 

        var selectElement = $(this).find('select');
        selectElement.focus();

        selectElement.on('change blur', function(e) {
            var newValue = $(this).val();
            
            if (e.type === 'blur' && newValue === oldValue) {
                table.row(cell.index().row).invalidate().draw(); 
                return;
            }

            var postData = {
                id: id, 
                status: newValue
            };
            
            $.post('ce_update.php', postData, function(res){
                if(res.success){
                    cell.data(newValue).draw();
                    table.row(cell.index().row).invalidate().draw(); 
                } else {
                    alert(res.error || 'Status update failed.');
                    table.row(cell.index().row).invalidate().draw();
                }
            }, 'json').fail(function() {
                alert('Server communication failed for status update.');
                table.row(cell.index().row).invalidate().draw();
            });
        });

    } 
    // For Word Count column (10), use a text input
    else if (field === 'word_count') {
        cell.data('<input type="text" class="form-control form-control-sm" value="'+oldValue+'">');
        var inputElement = $(this).find('input');
        inputElement.focus().select();

        inputElement.on('blur keyup', function(e){
            if(e.type === 'blur' || e.key === 'Enter'){
                var newValue = $(this).val();
                
                if(String(newValue).trim() === String(oldValue).trim()){
                    table.row(cell.index().row).invalidate().draw();
                    return;
                }

                newValue = String(newValue).trim();
                
                var postData = {
                    id: id, 
                    word_count: newValue
                };
                
                // Update Done By and CE Date (tracking info) on Word Count update
                $.post('ce_update.php', postData, function(res){
                    if(res.success){
                        cell.data(newValue).draw();
                        
                        if (res.done_by) { table.cell(cell.index().row, 14).data(res.done_by).draw(); }
                        if (res.ce_date) { table.cell(cell.index().row, 15).data(res.ce_date).draw(); }

                        table.row(cell.index().row).invalidate().draw();
                    } else {
                        alert(res.error || 'Word count update failed.');
                        table.row(cell.index().row).invalidate().draw();
                    }
                }, 'json').fail(function() {
                    alert('Server communication failed for word count update.');
                    table.row(cell.index().row).invalidate().draw();
                });
            }
        });
    }
});

// --------------------------------------------------------------------------------
// 5. CELL-LEVEL ASSIGN TO ME HANDLER (Flag 0 -> Flag 1) 
// --------------------------------------------------------------------------------
$('#ceTable').on('click', '.assign-cell-btn', function(e) {
    e.stopPropagation(); 

    var button = $(this);
    var cellElement = button.closest('td');
    var cell = table.cell(cellElement);
    var id = button.data('id');
    var field = button.data('field'); 
    var cell_data = cell.data(); 

    button.prop('disabled', true).html('<i class="bi bi-arrow-clockwise spin"></i>');

    var postData = {
        id: id, 
        [field]: cell_data, 
        set_check_flag: 1 
    };
    
    // On Flag 1 assignment, update Done By, CE Date, and the cell data itself (new_data)
    $.post('ce_update.php', postData, function(res){
        if(res.success){
            if (res.done_by) { 
                table.cell(cell.index().row, 14).data(res.done_by).draw();
            }
            if (res.ce_date) { 
                table.cell(cell.index().row, 15).data(res.ce_date).draw();
            }
            if (res.new_data) {
                cell.data(res.new_data); 
            }
            
            // Update status cell if status was changed to 'In Progress'
            if(res.status_updated){
                 table.cell(cell.index().row, 13).data('In Progress');
            }
            // Force full reload to ensure the UI gets the definitive check flag=1 data for all cells.
            table.ajax.reload(null, false);
            
        } else {
            alert(res.error || 'Cell assignment failed.');
            table.ajax.reload(null, false); 
        }
    }, 'json').fail(function() {
        alert('Server communication failed for cell assignment.');
         table.ajax.reload(null, false); 
    }).always(function() {
         button.prop('disabled', false).html('<i class="bi bi-person-fill-add"></i>');
    });
});
    
});
</script>
