<?php
session_start();
require 'db.php'; 

header('Content-Type: application/json');

// --- This query must return the correctly named columns ---
$query = "SELECT 
            id, 
            job_id, 
            date, 
            client, 
            issue, 
            articles, 
            eq, 
            images, 
            tables_count, 
            process, 
            word_count, 
            ref, 
            tat, 
            status, 
            done_by, 
            ce_date,
            eq_check,
            images_check,
            tables_count_check,
            ref_check
          FROM ce  where status!='Completed'
          ORDER BY id DESC"; 

$result = $mysqli->query($query);

$data = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        // Ensure null values are converted to appropriate display strings
        foreach ($row as $key => $value) {
            if ($value === null) {
                $row[$key] = '';
            }
        }
        $data[] = $row;
    }
    $result->free();
}

// DataTables expects the data in the 'data' key
echo json_encode(['data' => $data]);
?>