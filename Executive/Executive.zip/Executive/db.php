<?php
$servername = "localhost";
$username   = "root";     
$password   = "tapasi";         
$dbname     = "tapasi_erp"; 


$mysqli = new mysqli($servername, $username, $password, $dbname);

if ($mysqli->connect_error) {
    die("Database connection failed: " . $mysqli->connect_error);
}
?>
